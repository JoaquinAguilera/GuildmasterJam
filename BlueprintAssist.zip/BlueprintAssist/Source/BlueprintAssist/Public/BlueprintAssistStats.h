// Copyright fpwong. All Rights Reserved.

#pragma once

DECLARE_STATS_GROUP(TEXT("BlueprintAssist_EdGraphFormatter"), STATGROUP_BA_EdGraphFormatter, STATCAT_Advanced);