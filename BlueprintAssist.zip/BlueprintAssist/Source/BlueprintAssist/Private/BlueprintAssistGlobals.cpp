// Copyright fpwong. All Rights Reserved.

#include "BlueprintAssistGlobals.h"

DEFINE_LOG_CATEGORY(LogBlueprintAssist);